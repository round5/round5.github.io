/*
 * Copyright (c) 2018, Koninklijke Philips N.V.
 * Hayo Baan
 *
 * All rights reserved. A copyright license for redistribution and use in
 * source and binary forms, with or without modification, is hereby granted for
 * non-commercial, experimental, research, public review and evaluation
 * purposes, provided that the following conditions are met:
 *
 * * Redistributions of source code must retain the above copyright notice,
 *   this list of conditions and the following disclaimer.
 *
 * * Redistributions in binary form must reproduce the above copyright notice,
 *   this list of conditions and the following disclaimer in the documentation
 *   and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

/**
 * @file
 * Implementation of the Keccak hash functions.
 *
 * The implementation of the Keccak permutation function is based on the
 * public domain implementation in
 * http://keccak.noekeon.org/KeccakReferenceAndOptimized-3.2.zip
 * (Sources/KeccakF-1600-opt64.c and related files) by Guido Bertoni,
 *  Joan Daemen, Michaël Peeters and Gilles Van Assche.
 *
 * The implementation of the Keccak absorb and squeeze functions are
 * based on the public domain "TweetFips202" implementation from
 * https://twitter.com/tweetfips202 by Gilles Van Assche, Daniel
 * J. Bernstein, and Peter Schwabe (see also
 * Standalone/CompactFIPS202/TweetableFIPS202.c at
 * https://github.com/gvanas/KeccakCodePackage/ for a more readable
 * version).
 */

#include "keccak.h"
#include <string.h>
#include "little_endian.h"

/*******************************************************************************
 * Private macros, constants, and functions
 ******************************************************************************/

/**
 * Left Rotates a 64 bit value by the given number of bits.
 *
 * @param[in,out]   v   the value
 * @param[in]       c   the number of bits to rotate left (max 64)
 */
#define ROL64(v,c) ((v << c) | (v >> (64-c)))

/**
 * Declares the various variables used in a Keccak round.
 */
#define DECLARE_ABCDE \
    uint64_t Aba, Abe, Abi, Abo, Abu; \
    uint64_t Aga, Age, Agi, Ago, Agu; \
    uint64_t Aka, Ake, Aki, Ako, Aku; \
    uint64_t Ama, Ame, Ami, Amo, Amu; \
    uint64_t Asa, Ase, Asi, Aso, Asu; \
    uint64_t Bba, Bbe, Bbi, Bbo, Bbu; \
    uint64_t Bga, Bge, Bgi, Bgo, Bgu; \
    uint64_t Bka, Bke, Bki, Bko, Bku; \
    uint64_t Bma, Bme, Bmi, Bmo, Bmu; \
    uint64_t Bsa, Bse, Bsi, Bso, Bsu; \
    uint64_t Ca, Ce, Ci, Co, Cu; \
    uint64_t Da, De, Di, Do, Du; \
    uint64_t Eba, Ebe, Ebi, Ebo, Ebu; \
    uint64_t Ega, Ege, Egi, Ego, Egu; \
    uint64_t Eka, Eke, Eki, Eko, Eku; \
    uint64_t Ema, Eme, Emi, Emo, Emu; \
    uint64_t Esa, Ese, Esi, Eso, Esu; \

/**
 * Code to prepare Theta in a Keccak round.
 */
#define PREPARE_THETA \
    Ca = Aba^Aga^Aka^Ama^Asa; \
    Ce = Abe^Age^Ake^Ame^Ase; \
    Ci = Abi^Agi^Aki^Ami^Asi; \
    Co = Abo^Ago^Ako^Amo^Aso; \
    Cu = Abu^Agu^Aku^Amu^Asu; \

/**
 * Code for a Keccak round, with a prepare theta step, 64-bit lanes mapped to
 * 64-bit words.
 *
 * @param   i   the round
 * @param   A   the base of the “A/E” round variables (see DECLARE_ABCDE macro),
 *              either A or E, depending on the round.
 * @param   E   the base of the “E/A” round variables (see DECLARE_ABCDE macro),
 *              either A or E, depending on the round.
 */
#define THETA_RHO_PI_CHI_IOTA_PREPARE_THETA(i, A, E) \
    Da = Cu^ROL64(Ce, 1); \
    De = Ca^ROL64(Ci, 1); \
    Di = Ce^ROL64(Co, 1); \
    Do = Ci^ROL64(Cu, 1); \
    Du = Co^ROL64(Ca, 1); \
\
    A##ba ^= Da; \
    Bba = A##ba; \
    A##ge ^= De; \
    Bbe = ROL64(A##ge, 44); \
    A##ki ^= Di; \
    Bbi = ROL64(A##ki, 43); \
    A##mo ^= Do; \
    Bbo = ROL64(A##mo, 21); \
    A##su ^= Du; \
    Bbu = ROL64(A##su, 14); \
    E##ba =   Bba ^((~Bbe)&  Bbi ); \
    E##ba ^= keccakf_round_constants[i]; \
    Ca = E##ba; \
    E##be =   Bbe ^((~Bbi)&  Bbo ); \
    Ce = E##be; \
    E##bi =   Bbi ^((~Bbo)&  Bbu ); \
    Ci = E##bi; \
    E##bo =   Bbo ^((~Bbu)&  Bba ); \
    Co = E##bo; \
    E##bu =   Bbu ^((~Bba)&  Bbe ); \
    Cu = E##bu; \
\
    A##bo ^= Do; \
    Bga = ROL64(A##bo, 28); \
    A##gu ^= Du; \
    Bge = ROL64(A##gu, 20); \
    A##ka ^= Da; \
    Bgi = ROL64(A##ka, 3); \
    A##me ^= De; \
    Bgo = ROL64(A##me, 45); \
    A##si ^= Di; \
    Bgu = ROL64(A##si, 61); \
    E##ga =   Bga ^((~Bge)&  Bgi ); \
    Ca ^= E##ga; \
    E##ge =   Bge ^((~Bgi)&  Bgo ); \
    Ce ^= E##ge; \
    E##gi =   Bgi ^((~Bgo)&  Bgu ); \
    Ci ^= E##gi; \
    E##go =   Bgo ^((~Bgu)&  Bga ); \
    Co ^= E##go; \
    E##gu =   Bgu ^((~Bga)&  Bge ); \
    Cu ^= E##gu; \
\
    A##be ^= De; \
    Bka = ROL64(A##be, 1); \
    A##gi ^= Di; \
    Bke = ROL64(A##gi, 6); \
    A##ko ^= Do; \
    Bki = ROL64(A##ko, 25); \
    A##mu ^= Du; \
    Bko = ROL64(A##mu, 8); \
    A##sa ^= Da; \
    Bku = ROL64(A##sa, 18); \
    E##ka =   Bka ^((~Bke)&  Bki ); \
    Ca ^= E##ka; \
    E##ke =   Bke ^((~Bki)&  Bko ); \
    Ce ^= E##ke; \
    E##ki =   Bki ^((~Bko)&  Bku ); \
    Ci ^= E##ki; \
    E##ko =   Bko ^((~Bku)&  Bka ); \
    Co ^= E##ko; \
    E##ku =   Bku ^((~Bka)&  Bke ); \
    Cu ^= E##ku; \
\
    A##bu ^= Du; \
    Bma = ROL64(A##bu, 27); \
    A##ga ^= Da; \
    Bme = ROL64(A##ga, 36); \
    A##ke ^= De; \
    Bmi = ROL64(A##ke, 10); \
    A##mi ^= Di; \
    Bmo = ROL64(A##mi, 15); \
    A##so ^= Do; \
    Bmu = ROL64(A##so, 56); \
    E##ma =   Bma ^((~Bme)&  Bmi ); \
    Ca ^= E##ma; \
    E##me =   Bme ^((~Bmi)&  Bmo ); \
    Ce ^= E##me; \
    E##mi =   Bmi ^((~Bmo)&  Bmu ); \
    Ci ^= E##mi; \
    E##mo =   Bmo ^((~Bmu)&  Bma ); \
    Co ^= E##mo; \
    E##mu =   Bmu ^((~Bma)&  Bme ); \
    Cu ^= E##mu; \
\
    A##bi ^= Di; \
    Bsa = ROL64(A##bi, 62); \
    A##go ^= Do; \
    Bse = ROL64(A##go, 55); \
    A##ku ^= Du; \
    Bsi = ROL64(A##ku, 39); \
    A##ma ^= Da; \
    Bso = ROL64(A##ma, 41); \
    A##se ^= De; \
    Bsu = ROL64(A##se, 2); \
    E##sa =   Bsa ^((~Bse)&  Bsi ); \
    Ca ^= E##sa; \
    E##se =   Bse ^((~Bsi)&  Bso ); \
    Ce ^= E##se; \
    E##si =   Bsi ^((~Bso)&  Bsu ); \
    Ci ^= E##si; \
    E##so =   Bso ^((~Bsu)&  Bsa ); \
    Co ^= E##so; \
    E##su =   Bsu ^((~Bsa)&  Bse ); \
    Cu ^= E##su; \
\

/**
 * Code for a Keccak round, 64-bit lanes mapped to 64-bit words.
 *
 * @param   i   the round
 * @param   A   the base of the “A/E” round variables (see DECLARE_ABCDE macro),
 *              either A or E, depending on the round.
 * @param   E   the base of the “E/A” round variables (see DECLARE_ABCDE macro),
 *              either A or E, depending on the round.
 */
#define THETA_RHO_PI_CHI_IOTA(i, A, E) \
    Da = Cu^ROL64(Ce, 1); \
    De = Ca^ROL64(Ci, 1); \
    Di = Ce^ROL64(Co, 1); \
    Do = Ci^ROL64(Cu, 1); \
    Du = Co^ROL64(Ca, 1); \
\
    A##ba ^= Da; \
    Bba = A##ba; \
    A##ge ^= De; \
    Bbe = ROL64(A##ge, 44); \
    A##ki ^= Di; \
    Bbi = ROL64(A##ki, 43); \
    A##mo ^= Do; \
    Bbo = ROL64(A##mo, 21); \
    A##su ^= Du; \
    Bbu = ROL64(A##su, 14); \
    E##ba =   Bba ^((~Bbe)&  Bbi ); \
    E##ba ^= keccakf_round_constants[i]; \
    E##be =   Bbe ^((~Bbi)&  Bbo ); \
    E##bi =   Bbi ^((~Bbo)&  Bbu ); \
    E##bo =   Bbo ^((~Bbu)&  Bba ); \
    E##bu =   Bbu ^((~Bba)&  Bbe ); \
\
    A##bo ^= Do; \
    Bga = ROL64(A##bo, 28); \
    A##gu ^= Du; \
    Bge = ROL64(A##gu, 20); \
    A##ka ^= Da; \
    Bgi = ROL64(A##ka, 3); \
    A##me ^= De; \
    Bgo = ROL64(A##me, 45); \
    A##si ^= Di; \
    Bgu = ROL64(A##si, 61); \
    E##ga =   Bga ^((~Bge)&  Bgi ); \
    E##ge =   Bge ^((~Bgi)&  Bgo ); \
    E##gi =   Bgi ^((~Bgo)&  Bgu ); \
    E##go =   Bgo ^((~Bgu)&  Bga ); \
    E##gu =   Bgu ^((~Bga)&  Bge ); \
\
    A##be ^= De; \
    Bka = ROL64(A##be, 1); \
    A##gi ^= Di; \
    Bke = ROL64(A##gi, 6); \
    A##ko ^= Do; \
    Bki = ROL64(A##ko, 25); \
    A##mu ^= Du; \
    Bko = ROL64(A##mu, 8); \
    A##sa ^= Da; \
    Bku = ROL64(A##sa, 18); \
    E##ka =   Bka ^((~Bke)&  Bki ); \
    E##ke =   Bke ^((~Bki)&  Bko ); \
    E##ki =   Bki ^((~Bko)&  Bku ); \
    E##ko =   Bko ^((~Bku)&  Bka ); \
    E##ku =   Bku ^((~Bka)&  Bke ); \
\
    A##bu ^= Du; \
    Bma = ROL64(A##bu, 27); \
    A##ga ^= Da; \
    Bme = ROL64(A##ga, 36); \
    A##ke ^= De; \
    Bmi = ROL64(A##ke, 10); \
    A##mi ^= Di; \
    Bmo = ROL64(A##mi, 15); \
    A##so ^= Do; \
    Bmu = ROL64(A##so, 56); \
    E##ma =   Bma ^((~Bme)&  Bmi ); \
    E##me =   Bme ^((~Bmi)&  Bmo ); \
    E##mi =   Bmi ^((~Bmo)&  Bmu ); \
    E##mo =   Bmo ^((~Bmu)&  Bma ); \
    E##mu =   Bmu ^((~Bma)&  Bme ); \
\
    A##bi ^= Di; \
    Bsa = ROL64(A##bi, 62); \
    A##go ^= Do; \
    Bse = ROL64(A##go, 55); \
    A##ku ^= Du; \
    Bsi = ROL64(A##ku, 39); \
    A##ma ^= Da; \
    Bso = ROL64(A##ma, 41); \
    A##se ^= De; \
    Bsu = ROL64(A##se, 2); \
    E##sa =   Bsa ^((~Bse)&  Bsi ); \
    E##se =   Bse ^((~Bsi)&  Bso ); \
    E##si =   Bsi ^((~Bso)&  Bsu ); \
    E##so =   Bso ^((~Bsu)&  Bsa ); \
    E##su =   Bsu ^((~Bsa)&  Bse ); \
\

/**
 * Copies a state into the round variables with the specified name.
 *
 * @param   X       the base of the round variables.
 * @param   state   the state
 */
#define COPY_FROM_STATE(X, state) \
    X##ba = state[ 0]; \
    X##be = state[ 1]; \
    X##bi = state[ 2]; \
    X##bo = state[ 3]; \
    X##bu = state[ 4]; \
    X##ga = state[ 5]; \
    X##ge = state[ 6]; \
    X##gi = state[ 7]; \
    X##go = state[ 8]; \
    X##gu = state[ 9]; \
    X##ka = state[10]; \
    X##ke = state[11]; \
    X##ki = state[12]; \
    X##ko = state[13]; \
    X##ku = state[14]; \
    X##ma = state[15]; \
    X##me = state[16]; \
    X##mi = state[17]; \
    X##mo = state[18]; \
    X##mu = state[19]; \
    X##sa = state[20]; \
    X##se = state[21]; \
    X##si = state[22]; \
    X##so = state[23]; \
    X##su = state[24]; \

/**
 * Copies the round variables with the specified name into the state.
 *
 * @param   state   the state
 * @param   X       the base of the round variables.
 */
#define COPY_TO_STATE(state, X) \
    state[ 0] = X##ba; \
    state[ 1] = X##be; \
    state[ 2] = X##bi; \
    state[ 3] = X##bo; \
    state[ 4] = X##bu; \
    state[ 5] = X##ga; \
    state[ 6] = X##ge; \
    state[ 7] = X##gi; \
    state[ 8] = X##go; \
    state[ 9] = X##gu; \
    state[10] = X##ka; \
    state[11] = X##ke; \
    state[12] = X##ki; \
    state[13] = X##ko; \
    state[14] = X##ku; \
    state[15] = X##ma; \
    state[16] = X##me; \
    state[17] = X##mi; \
    state[18] = X##mo; \
    state[19] = X##mu; \
    state[20] = X##sa; \
    state[21] = X##se; \
    state[22] = X##si; \
    state[23] = X##so; \
    state[24] = X##su; \

/**
 * Code for the 24 rounds of Keccak.
 */
#define ROUNDS \
    PREPARE_THETA \
    THETA_RHO_PI_CHI_IOTA_PREPARE_THETA( 0, A, E) \
    THETA_RHO_PI_CHI_IOTA_PREPARE_THETA( 1, E, A) \
    THETA_RHO_PI_CHI_IOTA_PREPARE_THETA( 2, A, E) \
    THETA_RHO_PI_CHI_IOTA_PREPARE_THETA( 3, E, A) \
    THETA_RHO_PI_CHI_IOTA_PREPARE_THETA( 4, A, E) \
    THETA_RHO_PI_CHI_IOTA_PREPARE_THETA( 5, E, A) \
    THETA_RHO_PI_CHI_IOTA_PREPARE_THETA( 6, A, E) \
    THETA_RHO_PI_CHI_IOTA_PREPARE_THETA( 7, E, A) \
    THETA_RHO_PI_CHI_IOTA_PREPARE_THETA( 8, A, E) \
    THETA_RHO_PI_CHI_IOTA_PREPARE_THETA( 9, E, A) \
    THETA_RHO_PI_CHI_IOTA_PREPARE_THETA(10, A, E) \
    THETA_RHO_PI_CHI_IOTA_PREPARE_THETA(11, E, A) \
    THETA_RHO_PI_CHI_IOTA_PREPARE_THETA(12, A, E) \
    THETA_RHO_PI_CHI_IOTA_PREPARE_THETA(13, E, A) \
    THETA_RHO_PI_CHI_IOTA_PREPARE_THETA(14, A, E) \
    THETA_RHO_PI_CHI_IOTA_PREPARE_THETA(15, E, A) \
    THETA_RHO_PI_CHI_IOTA_PREPARE_THETA(16, A, E) \
    THETA_RHO_PI_CHI_IOTA_PREPARE_THETA(17, E, A) \
    THETA_RHO_PI_CHI_IOTA_PREPARE_THETA(18, A, E) \
    THETA_RHO_PI_CHI_IOTA_PREPARE_THETA(19, E, A) \
    THETA_RHO_PI_CHI_IOTA_PREPARE_THETA(20, A, E) \
    THETA_RHO_PI_CHI_IOTA_PREPARE_THETA(21, E, A) \
    THETA_RHO_PI_CHI_IOTA_PREPARE_THETA(22, A, E) \
    THETA_RHO_PI_CHI_IOTA(23, E, A) \
    COPY_TO_STATE(state, A)

/**
 * Pre-computed round constants.
 */
static const uint64_t keccakf_round_constants[24] = {
    /* Since C89 does not support long long literals, we create the constants
     * in two steps with one part shifted 32 bits to the left */
    ((uint64_t) 0x00000000 << 32) | 0x00000001,
    ((uint64_t) 0x00000000 << 32) | 0x00008082,
    ((uint64_t) 0x80000000 << 32) | 0x0000808a,
    ((uint64_t) 0x80000000 << 32) | 0x80008000,
    ((uint64_t) 0x00000000 << 32) | 0x0000808b,
    ((uint64_t) 0x00000000 << 32) | 0x80000001,
    ((uint64_t) 0x80000000 << 32) | 0x80008081,
    ((uint64_t) 0x80000000 << 32) | 0x00008009,
    ((uint64_t) 0x00000000 << 32) | 0x0000008a,
    ((uint64_t) 0x00000000 << 32) | 0x00000088,
    ((uint64_t) 0x00000000 << 32) | 0x80008009,
    ((uint64_t) 0x00000000 << 32) | 0x8000000a,
    ((uint64_t) 0x00000000 << 32) | 0x8000808b,
    ((uint64_t) 0x80000000 << 32) | 0x0000008b,
    ((uint64_t) 0x80000000 << 32) | 0x00008089,
    ((uint64_t) 0x80000000 << 32) | 0x00008003,
    ((uint64_t) 0x80000000 << 32) | 0x00008002,
    ((uint64_t) 0x80000000 << 32) | 0x00000080,
    ((uint64_t) 0x00000000 << 32) | 0x0000800a,
    ((uint64_t) 0x80000000 << 32) | 0x8000000a,
    ((uint64_t) 0x80000000 << 32) | 0x80008081,
    ((uint64_t) 0x80000000 << 32) | 0x00008080,
    ((uint64_t) 0x00000000 << 32) | 0x80000001,
    ((uint64_t) 0x80000000 << 32) | 0x80008008
};

/**
 * Main Keccak-f[1600] state permutation function.
 *
 * @param[in,out]   state   the state
 */
static void keccak_permutation_on_words(uint64_t state[25]) {
    DECLARE_ABCDE;

    COPY_FROM_STATE(A, state);
    ROUNDS;
}

/*******************************************************************************
 * Public functions
 ******************************************************************************/

void keccak_absorb(uint64_t state[25], const unsigned int rate, const unsigned char *input, size_t len, const unsigned char padding) {
    static unsigned char temp_result[200]; /* More than enough for any of the current SHA3/SHAKE algorithms */
    size_t i;

    /* Clear state */
    memset(state, 0, 25 * sizeof (uint64_t));

    /* Absorb all input blocks */
    while (len >= rate) {
        for (i = 0; i < (rate >> 3); ++i)
            state[i] ^= u64_from_le(input + 8 * i);

        keccak_permutation_on_words(state);
        len -= rate;
        input += rate;
    }

    /* Store remaining input in intermediate result */
    memcpy(temp_result, input, len);

    /* Clear rest of intermediate result */
    memset(temp_result + len, 0, rate - len);


    /* Add padding */
    temp_result[len] = padding;
    temp_result[rate - 1] |= 0x80;

    /* Store result in state */
    for (i = 0; i < rate / 8; ++i)
        state[i] ^= u64_from_le(temp_result + 8 * i);
}

void keccak_squeezeblocks(uint64_t state[25], unsigned char *hash, size_t nr_blocks, const unsigned int rate) {
    size_t i;
    for (; nr_blocks > 0; --nr_blocks) {
        keccak_permutation_on_words(state);
        for (i = 0; i < (rate >> 3); i++) {
            u64_to_le(hash + 8 * i, state[i]);
        }
        hash += rate;
    }
}

void keccak(unsigned char *hash, const size_t nr_blocks, const unsigned int rate, const unsigned char *input, size_t len, const unsigned char padding) {
    static uint64_t state[64];

    keccak_absorb(state, rate, input, len, padding);
    keccak_squeezeblocks(state, hash, nr_blocks, rate);
}
