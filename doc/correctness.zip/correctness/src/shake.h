/*
 * Copyright (c) 2018, Koninklijke Philips N.V.
 * Hayo Baan
 *
 * All rights reserved. A copyright license for redistribution and use in
 * source and binary forms, with or without modification, is hereby granted for
 * non-commercial, experimental, research, public review and evaluation
 * purposes, provided that the following conditions are met:
 *
 * * Redistributions of source code must retain the above copyright notice,
 *   this list of conditions and the following disclaimer.
 *
 * * Redistributions in binary form must reproduce the above copyright notice,
 *   this list of conditions and the following disclaimer in the documentation
 *   and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

/**
 * @file
 * Declaration of the SHAKE128, SHAKE256, cSHAKE128, and cSHAKE256 hash
 * functions.
 *
 * Note: all sizes are in bytes, not bits!
 */

#ifndef SHAKE_H
#define SHAKE_H

#include <stdlib.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

#ifdef DOXYGEN
/* Document SHAKE implementation option macros */
/**
 * The default implementation of the SHAKE algorithm absorb and squeeze steps is
 * to make use of `libkeccak`. As an alternative a stand-alone implementation
 * can be used by defining `NO_LIBKECCAK_SHAKE`.
 *
 * Note: cSHAKE is always implemented using `libkeccak`.
 */
#define NO_LIBKECCAK_SHAKE

/**
 * The default implementation of the SHAKE algorithm when combining the absorb
 * and squeeze steps (i.e. when using the functions `shake128()` or `shake256()`)
 * is to make use of OpenSSL (if OpenSSL >= 1.1.1 is found). To use the standard
 * implementation (i.e. either from `libkeccak` or the stand-alone version),
 * define `NO_OPENSSL_SHAKE`.
 */
#define NO_OPENSSL_SHAKE
#endif

#ifdef NO_LIBKECCAK_SHAKE
#include "keccak.h"
typedef uint64_t shake_ctx[25]; /**< The shake context (state) */
#else
#include <libkeccak.a.headers/KeccakHash.h>
typedef Keccak_HashInstance shake_ctx; /**< The shake context (state) */
#endif

#include <libkeccak.a.headers/SP800-185.h>
typedef cSHAKE_Instance cshake_ctx; /**< The cshake context (state) */

/**
 * The rate of the SHAKE-128 algorithm (i.e. internal block size, in bytes).
 */
#define SHAKE128_RATE 168

/**
 * The rate of the SHAKE-256 algorithm (i.e. internal block size, in bytes).
 */
#define SHAKE256_RATE 136

#ifdef __cplusplus
extern "C" {
#endif

    /**
     * Performs the initialisation step of the SHAKE-128 XOF.
     *
     * @param ctx the shake context
     */
    inline void shake128_init(shake_ctx *ctx) {
#ifdef NO_LIBKECCAK_SHAKE
        memset(*ctx, 0, 25 * sizeof (uint64_t));
#else
        if (Keccak_HashInitialize_SHAKE128(ctx) != 0) {
            fprintf(stderr, "Error: Failed to initialize SHAKE128 context\n");
            exit(EXIT_FAILURE);
        }
#endif
    }

    /**
     * Performs the absorb step of the SHAKE-128 XOF.
     *
     * @param ctx the shake context
     * @param input the input absorbed into the state
     * @param input_len the length of the input
     */
    inline void shake128_absorb(shake_ctx *ctx, const unsigned char *input, const size_t input_len) {
#ifdef NO_LIBKECCAK_SHAKE
        keccak_absorb(*ctx, SHAKE128_RATE, input, input_len, 0x1f);
#else
        if (Keccak_HashUpdate(ctx, input, input_len * 8) != 0) {
            fprintf(stderr, "Error: Failed to update SHAKE128 context\n");
            exit(EXIT_FAILURE);
        }
        if (Keccak_HashFinal(ctx, NULL) != 0) {
            fprintf(stderr, "Error: Failed to finalize SHAKE128 context\n");
            exit(EXIT_FAILURE);
        }
#endif
    }

    /**
     * Performs the squeeze step of the SHAKE-128 XOF. Squeezes full blocks of
     * SHAKE128_RATE bytes each. Can be called multiple times to keep squeezing
     * (i.e. this function is incremental).
     *
     * @param ctx the shake context
     * @param output the output
     * @param nr_blocks the number of blocks to squeeze
     */
    inline void shake128_squeezeblocks(shake_ctx *ctx, unsigned char *output, const size_t nr_blocks) {
#ifdef NO_LIBKECCAK_SHAKE
        keccak_squeezeblocks(*ctx, output, nr_blocks, SHAKE128_RATE);
#else
        if (Keccak_HashSqueeze(ctx, output, nr_blocks * SHAKE128_RATE * 8) != 0) {
            fprintf(stderr, "Error: Failed to squeeze SHAKE128 context\n");
            exit(EXIT_FAILURE);
        }
#endif
    }

    /**
     * Performs the full SHAKE-128 XOF to the given input.
     * @param output the final output
     * @param output_len the length of the output
     * @param input the input
     * @param input_len the length of the input
     */
    void shake128(unsigned char *output, size_t output_len, const unsigned char *input, const size_t input_len);

    /**
     * Performs the initialisation step of the SHAKE-256 XOF.
     *
     * @param ctx the shake context
     */
    inline void shake256_init(shake_ctx *ctx) {
#ifdef NO_LIBKECCAK_SHAKE
        memset(*ctx, 0, 25 * sizeof (uint64_t));
#else
        if (Keccak_HashInitialize_SHAKE256(ctx) != 0) {
            fprintf(stderr, "Error: Failed to initialize SHAKE256 context\n");
            exit(EXIT_FAILURE);
        }
#endif
    }

    /**
     * Performs the absorb step of the SHAKE-256 XOF.
     *
     * @param ctx the shake context
     * @param input the input absorbed into the state
     * @param input_len the length of the input
     */
    inline void shake256_absorb(shake_ctx *ctx, const unsigned char *input, const size_t input_len) {
#ifdef NO_LIBKECCAK_SHAKE
        keccak_absorb(*ctx, SHAKE256_RATE, input, input_len, 0x1f);
#else
        if (Keccak_HashUpdate(ctx, input, input_len * 8) != 0) {
            fprintf(stderr, "Error: Failed to update SHAKE256 context\n");
            exit(EXIT_FAILURE);
        }
        if (Keccak_HashFinal(ctx, NULL) != 0) {
            fprintf(stderr, "Error: Failed to finalize SHAKE256 context\n");
            exit(EXIT_FAILURE);
        }
#endif
    }

    /**
     * Performs the squeeze step of the SHAKE-256 XOF. Squeezes full blocks of
     * SHAKE256_RATE bytes each. Can be called multiple times to keep squeezing
     * (i.e. this function is incremental).
     *
     * @param ctx the shake context
     * @param output the output
     * @param nr_blocks the number of blocks to squeeze
     */
    inline void shake256_squeezeblocks(shake_ctx *ctx, unsigned char *output, const size_t nr_blocks) {
#ifdef NO_LIBKECCAK_SHAKE
        keccak_squeezeblocks(*ctx, output, nr_blocks, SHAKE256_RATE);
#else
        if (Keccak_HashSqueeze(ctx, output, nr_blocks * SHAKE256_RATE * 8) != 0) {
            fprintf(stderr, "Error: Failed to squeeze SHAKE256 context\n");
            exit(EXIT_FAILURE);
        }
#endif
    }

    /**
     * Performs the full SHAKE-256 XOF to the given input.
     * @param output the final output
     * @param output_len the length of the output
     * @param input the input
     * @param input_len the length of the input
     */
    void shake256(unsigned char *output, const size_t output_len, const unsigned char *input, const size_t input_len);

    /**
     * Performs the initialisation step of the cSHAKE-128 XOF.
     *
     * @param ctx the cshake context
     * @param customization the customization string
     * @param customization_len the length of the customization string
     */
    inline void cshake128_init(cshake_ctx *ctx, const unsigned char *customization, const size_t customization_len) {
        if (cSHAKE128_Initialize(ctx, 0, NULL, 0, customization, customization_len * 8) != 0) {
            fprintf(stderr, "Error: Failed to initialize cSHAKE128 context\n");
            exit(EXIT_FAILURE);
        }
    }

    /**
     * Performs the absorb step of the cSHAKE-128 XOF.
     *
     * @param ctx the cshake context
     * @param input the input absorbed into the state
     * @param input_len the length of the input
     */
    inline void cshake128_absorb(cshake_ctx *ctx, const unsigned char *input, const size_t input_len) {
        if (cSHAKE128_Update(ctx, input, input_len * 8) != 0) {
            fprintf(stderr, "Error: Failed to update cSHAKE128 context\n");
            exit(EXIT_FAILURE);
        }
        if (cSHAKE128_Final(ctx, NULL) != 0) {
            fprintf(stderr, "Error: Failed to finalize cSHAKE128 context\n");
            exit(EXIT_FAILURE);
        }
    }

    /**
     * Performs the squeeze step of the cSHAKE-128 XOF. Squeezes full blocks of
     * SHAKE128_RATE bytes each. Can be called multiple times to keep squeezing
     * (i.e. this function is incremental).
     *
     * @param ctx the cshake context
     * @param output the output
     * @param nr_blocks the number of blocks to squeeze
     */
    inline void cshake128_squeezeblocks(cshake_ctx *ctx, unsigned char *output, const size_t nr_blocks) {
        if (cSHAKE128_Squeeze(ctx, output, nr_blocks * SHAKE128_RATE * 8) != 0) {
            fprintf(stderr, "Error: Failed to squeeze cSHAKE128 context\n");
            exit(EXIT_FAILURE);
        }
    }

    /**
     * Performs the full cSHAKE-128 XOF to the given input.
     * @param output the final output
     * @param output_len the length of the output
     * @param input the input
     * @param input_len the length of the input
     * @param customization the customization string
     * @param customization_len the length of the customization string
     */
    inline void cshake128(unsigned char *output, size_t output_len, const unsigned char *input, const size_t input_len, const unsigned char *customization, const size_t customization_len) {
        if (cSHAKE128(input, input_len * 8, output, output_len * 8, NULL, 0, customization, customization_len) != 0) {
            fprintf(stderr, "Error: Failed to perform cSHAKE128\n");
            exit(EXIT_FAILURE);
        }
    }

    /**
     * Performs the initialisation step of the cSHAKE-256 XOF.
     *
     * @param ctx the cshake context
     * @param customization the customization string
     * @param customization_len the length of the customization string
     */
    inline void cshake256_init(cshake_ctx *ctx, const unsigned char *customization, const size_t customization_len) {
        if (cSHAKE256_Initialize(ctx, 0, NULL, 0, customization, customization_len * 8) != 0) {
            fprintf(stderr, "Error: Failed to initialize cSHAKE256 context\n");
            exit(EXIT_FAILURE);
        }
    }

    /**
     * Performs the absorb step of the cSHAKE-256 XOF.
     *
     * @param ctx the cshake context
     * @param input the input absorbed into the state
     * @param input_len the length of the input
     */
    inline void cshake256_absorb(cshake_ctx *ctx, const unsigned char *input, const size_t input_len) {
        if (cSHAKE256_Update(ctx, input, input_len * 8) != 0) {
            fprintf(stderr, "Error: Failed to update cSHAKE256 context\n");
            exit(EXIT_FAILURE);
        }
        if (cSHAKE256_Final(ctx, NULL) != 0) {
            fprintf(stderr, "Error: Failed to finalize cSHAKE256 context\n");
            exit(EXIT_FAILURE);
        }
    }

    /**
     * Performs the squeeze step of the cSHAKE-256 XOF. Squeezes full blocks of
     * SHAKE256_RATE bytes each. Can be called multiple times to keep squeezing
     * (i.e. this function is incremental).
     *
     * @param ctx the cshake context
     * @param output the output
     * @param nr_blocks the number of blocks to squeeze
     */
    inline void cshake256_squeezeblocks(cshake_ctx *ctx, unsigned char *output, const size_t nr_blocks) {
        if (cSHAKE256_Squeeze(ctx, output, nr_blocks * SHAKE256_RATE * 8) != 0) {
            fprintf(stderr, "Error: Failed to squeeze cSHAKE256 context\n");
            exit(EXIT_FAILURE);
        }
    }

    /**
     * Performs the full cSHAKE-256 XOF to the given input.
     * @param output the final output
     * @param output_len the length of the output
     * @param input the input
     * @param input_len the length of the input
     * @param customization the customization string
     * @param customization_len the length of the customization string
     */
    inline void cshake256(unsigned char *output, size_t output_len, const unsigned char *input, const size_t input_len, const unsigned char *customization, const size_t customization_len) {
        if (cSHAKE256(input, input_len * 8, output, output_len * 8, NULL, 0, customization, customization_len) != 0) {
            fprintf(stderr, "Error: Failed to perform cSHAKE128\n");
            exit(EXIT_FAILURE);
        }
    }

#ifdef __cplusplus
}
#endif

#endif /* SHAKE_H */
