/*
 * Copyright (c) 2018, Koninklijke Philips N.V.
 * Hayo Baan
 *
 * All rights reserved. A copyright license for redistribution and use in
 * source and binary forms, with or without modification, is hereby granted for
 * non-commercial, experimental, research, public review and evaluation
 * purposes, provided that the following conditions are met:
 *
 * * Redistributions of source code must retain the above copyright notice,
 *   this list of conditions and the following disclaimer.
 *
 * * Redistributions in binary form must reproduce the above copyright notice,
 *   this list of conditions and the following disclaimer in the documentation
 *   and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

/**
 * @file
 * Declaration of the Keccak hash functions.
 */

#ifndef KECCAK_H
#define KECCAK_H

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

    /**
     * Absorb part of the keccak hash function (Keccak-f[1600]).
     *
     * @param[out]  state   the state
     * @param[in]   rate    the rate of the algorithm (e.g. 168 for SHAKE-128, 136 for SHA3-256)
     * @param[in]   input   the input message
     * @param[in]   len     the length of the input message
     * @param[in]   padding the padding character (e.g. 0x1f for SHAKE-128, 0x06 for SHA3-256)
     */
    void keccak_absorb(uint64_t state[25], const unsigned int rate, const unsigned char *input, size_t len, const unsigned char padding);

    /**
     * Squeeze part of the keccak hash function (Keccak-f[1600]).
     *
     * @param[out]    hash      the full hash (rate * nr_blocks bytes)
     * @param[in,out] state     the state
     * @param[in]     nr_blocks the number of blocks to squeeze
     * @param[in]     rate      the rate of the algorithm (e.g. 168 for SHAKE-128, 136 for SHA3-256)
     */
    void keccak_squeezeblocks(uint64_t state[25], unsigned char *hash, size_t nr_blocks, const unsigned int rate);

    /**
     * The complete keccak hash function (Keccak-f[1600]).
     *
     * @param[out] hash      the full hash (rate * nr_blocks bytes)
     * @param[in]  nr_blocks the number of blocks to squeeze (e.g. 1 for
     *                       SHA3-<i>xxx</i>)
     * @param[in]  rate      the rate of the algorithm (e.g. 168 for SHAKE-128,
     *                       136 for SHA3-256)
     * @param[in]  input     the input message
     * @param[in]  len       the length of the input message
     * @param[in]  padding   the padding character (e.g. 0x1f for SHAKE-128,
     *                       0x06 for SHA3-<i>xxx</i>)
     */
    void keccak(unsigned char *hash, const size_t nr_blocks, const unsigned int rate, const unsigned char *input, const size_t len, const unsigned char padding);

#ifdef __cplusplus
}
#endif

#endif /* KECCAK_H */
