/*
 * Copyright (c) 2018, PQShield and Koninklijke Philips N.V.
 * Markku-Juhani O. Saarinen, Oscar Garcia-Morchon, Hayo Baan
 *
 * All rights reserved. A copyright license for redistribution and use in
 * source and binary forms, with or without modification, is hereby granted for
 * non-commercial, experimental, research, public review and evaluation
 * purposes, provided that the following conditions are met:
 *
 * * Redistributions of source code must retain the above copyright notice,
 *   this list of conditions and the following disclaimer.
 *
 * * Redistributions in binary form must reproduce the above copyright notice,
 *   this list of conditions and the following disclaimer in the documentation
 *   and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

// Fast ring arithmetic (with cache attack countermeasures)

#include "ringmul.h"

#if PARAMS_K == 1 && defined(CM_CACHE)

#include "drbg.h"
#include "little_endian.h"

#include <string.h>

#define PROBEVEC64  ((PARAMS_ND + 63) / 64)

// Cache-resistant "occupancy probe". Tests and "occupies" a single slot at x.
// Return value zero (false) indicates the slot was originally empty.

static int probe_cm(uint64_t *v, int x) {
    int i;
    uint64_t a, b, c, y, z;

    // construct the selector
    y = (1llu) << (x & 0x3F); // low bits of index

#if 0
    z = (1llu) << (x >> 6); // high bits of index
#else
    z = 1llu; // no constant-time 64-bit shift
    a = (uint64_t) (-((x >> 6) & 1));
    z = ((z << 1) & a) ^ (z & ~a);
    a = (uint64_t) (-((x >> 7) & 1));
    z = ((z << 2) & a) ^ (z & ~a);
    a = (uint64_t) (-((x >> 8) & 1));
    z = ((z << 4) & a) ^ (z & ~a);
    a = (uint64_t) (-((x >> 9) & 1));
    z = ((z << 8) & a) ^ (z & ~a);
    a = (uint64_t) (-((x >> 10) & 1)); // can handle up to n=d=2048
    z = ((z << 16) & a) ^ (z & ~a);
#endif

    c = 0;
    for (i = 0; i < PROBEVEC64; i++) { // always scan through all
        a = v[i];
        b = a | (y & (-(z & 1))); // set bit
        c |= a ^ b; // mask for change
        v[i] = b;
        z >>= 1;
    }

    // final comparison doesn't need to be constant time
    return c == 0; // return true if was occupied
}

// create a sparse ternary vector from a seed

void create_secret_vector(uint16_t idx[PARAMS_H / 2][2], const uint8_t *seed, const size_t seed_size) {
    size_t i;
    uint16_t x;
    uint64_t v[PROBEVEC64];

    memset(v, 0, sizeof (v));
    drbg_init(seed, seed_size);

    for (i = 0; i < PARAMS_H; i++) {
        do {
            do {
                drbg(&x, sizeof (x));
                x = (uint16_t) LITTLE_ENDIAN16(x);
            } while (x >= PARAMS_RS_LIM);
            x /= PARAMS_RS_DIV;
        } while (probe_cm(v, x));
        idx[i >> 1][i & 1] = x; // addition / subtract index
    }
}

// multiplication mod q, result length n

void ringmul_q(modq_t d[PARAMS_ND + PARAMS_LOOP_UNROLL], modq_t a[PARAMS_ND], uint16_t idx[PARAMS_H / 2][2]) {
    size_t i, j, k;
    modq_t t, p[PARAMS_ND + 1];

    // Note: order of coefficients a[1..n] is reversed!
    // "lift" -- multiply by (x - 1)
    p[0] = (modq_t) (-a[0]);
    for (i = 1; i < PARAMS_ND; i++) {
        p[PARAMS_ND + 1 - i] = (modq_t) (a[i - 1] - a[i]);
    }
    p[1] = a[PARAMS_ND - 1];

    // Initialize result
    memset(d, 0, PARAMS_ND * sizeof (modq_t));

    for (i = 0; i < PARAMS_H / 2; i++) {
        // Modified to always scan the same ranges

        k = idx[i][0]; // positive coefficients
        d[0] = (modq_t) (d[0] + p[k]);
        for (j = 1; k > 0;) {
            d[j] = (modq_t) (d[j] + p[--k]);
            j++;
        }
        for (k = PARAMS_ND + 1; j < PARAMS_ND;) {
            d[j] = (modq_t) (d[j] + p[--k]);
            j++;
        }

        k = idx[i][1]; // negative coefficients
        d[0] = (modq_t) (d[0] - p[k]);
        for (j = 1; k > 0;) {
            d[j] = (modq_t) (d[j] - p[--k]);
            j++;
        }
        for (k = PARAMS_ND + 1; j < PARAMS_ND;) {
            d[j] = (modq_t) (d[j] - p[--k]);
            j++;
        }
    }

    // "unlift"
    t = 0;
    for (i = 0; i < PARAMS_ND; i++) {
        t = (modq_t) (t - d[i]);
        d[i] = t;
    }
}

// multiplication mod p, result length mu

void ringmul_p(modp_t d[PARAMS_MU + PARAMS_LOOP_UNROLL], modp_t a[PARAMS_ND], uint16_t idx[PARAMS_H / 2][2]) {
    size_t i, j, k;
    modp_t p[PARAMS_ND + 1];

    // Note: order of coefficients a[1..n] is reversed!
#if (PARAMS_XE == 0) && (PARAMS_F == 0)
    // Without error correction we "lift" -- i.e. multiply by (x - 1)
    p[0] = (modp_t) (-a[0]);
    for (i = 1; i < PARAMS_ND; i++) {
        p[PARAMS_ND + 1 - i] = (modp_t) (a[i - 1] - a[i]);
    }
    p[1] = a[PARAMS_ND - 1];
#define SIZE_TMP_D PARAMS_ND
#else
    // With error correction we do not "lift"
    p[0] = a[0];
    for (i = 2; i < PARAMS_ND + 1; i++) {
        p[i] = a[PARAMS_ND + 1 - i];
    }
    p[1] = 0;
    // Since we do not unlift at the end, we actually need to compute one element more.
#define SIZE_TMP_D (PARAMS_ND+1)
#endif

    modp_t tmp_d[SIZE_TMP_D];

    // Initialize result
    memset(tmp_d, 0, SIZE_TMP_D * sizeof (modp_t));

    for (i = 0; i < PARAMS_H / 2; i++) {
        // Modified to always scan the same ranges

        k = idx[i][0]; // positive coefficients
        tmp_d[0] = (modp_t) (tmp_d[0] + p[k]);
        for (j = 1; k > 0;) {
            tmp_d[j] = (modp_t) (tmp_d[j] + p[--k]);
            j++;
        }
        for (k = PARAMS_ND + 1; j < SIZE_TMP_D;) {
            tmp_d[j] = (modp_t) (tmp_d[j] + p[--k]);
            j++;
        }

        k = idx[i][1]; // negative coefficients
        tmp_d[0] = (modp_t) (tmp_d[0] - p[k]);
        for (j = 1; k > 0;) {
            tmp_d[j] = (modp_t) (tmp_d[j] - p[--k]);
            j++;
        }
        for (k = PARAMS_ND + 1; j < SIZE_TMP_D;) {
            tmp_d[j] = (modp_t) (tmp_d[j] - p[--k]);
            j++;
        }
    }

#if (PARAMS_XE == 0) && (PARAMS_F == 0)
    // Without error correction we "lifted" so we now need to "unlift"
    modp_t t = 0;
    for (i = 0; i < PARAMS_ND; i++) {
        t = (modp_t) (t - tmp_d[i]);
        tmp_d[i] = t;
    }
#endif
    // Copy the last part to caller
    memcpy(d, tmp_d + SIZE_TMP_D - PARAMS_MU, PARAMS_MU * sizeof (modp_t));
}

#endif /* PARAMS_K == 1 && defined(CM_CACHE) */
